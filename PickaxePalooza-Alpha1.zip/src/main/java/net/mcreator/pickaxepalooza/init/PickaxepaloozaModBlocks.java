
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pickaxepalooza.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.pickaxepalooza.block.ZirconDeepOreBlock;
import net.mcreator.pickaxepalooza.block.ZirconBlockBlock;
import net.mcreator.pickaxepalooza.block.TourmalineOreBlock;
import net.mcreator.pickaxepalooza.block.TourmalineDeepOreBlock;
import net.mcreator.pickaxepalooza.block.TourmalineBlockBlock;
import net.mcreator.pickaxepalooza.block.SpinelDeepOreBlock;
import net.mcreator.pickaxepalooza.block.SpinelBlockBlock;
import net.mcreator.pickaxepalooza.block.PeridotEndstoneOreBlock;
import net.mcreator.pickaxepalooza.block.PeridotBlockBlock;
import net.mcreator.pickaxepalooza.block.OrbofObscurityBlock;
import net.mcreator.pickaxepalooza.block.OpalOreBlock;
import net.mcreator.pickaxepalooza.block.OpalBlockBlock;
import net.mcreator.pickaxepalooza.block.MantleKilnBlock;
import net.mcreator.pickaxepalooza.block.KunziteNetherOreBlock;
import net.mcreator.pickaxepalooza.block.KunziteBlockBlock;
import net.mcreator.pickaxepalooza.block.IoliteDeepOreBlock;
import net.mcreator.pickaxepalooza.block.IoliteBlockBlock;
import net.mcreator.pickaxepalooza.block.BarrenTombBlock;
import net.mcreator.pickaxepalooza.block.AmetrineNetherOreBlock;
import net.mcreator.pickaxepalooza.block.AmetrineBlockBlock;
import net.mcreator.pickaxepalooza.PickaxepaloozaMod;

public class PickaxepaloozaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, PickaxepaloozaMod.MODID);
	public static final RegistryObject<Block> TOURMALINE_ORE = REGISTRY.register("tourmaline_ore", () -> new TourmalineOreBlock());
	public static final RegistryObject<Block> TOURMALINE_DEEP_ORE = REGISTRY.register("tourmaline_deep_ore", () -> new TourmalineDeepOreBlock());
	public static final RegistryObject<Block> TOURMALINE_BLOCK = REGISTRY.register("tourmaline_block", () -> new TourmalineBlockBlock());
	public static final RegistryObject<Block> OPAL_ORE = REGISTRY.register("opal_ore", () -> new OpalOreBlock());
	public static final RegistryObject<Block> IOLITE_DEEP_ORE = REGISTRY.register("iolite_deep_ore", () -> new IoliteDeepOreBlock());
	public static final RegistryObject<Block> ZIRCON_DEEP_ORE = REGISTRY.register("zircon_deep_ore", () -> new ZirconDeepOreBlock());
	public static final RegistryObject<Block> SPINEL_DEEP_ORE = REGISTRY.register("spinel_deep_ore", () -> new SpinelDeepOreBlock());
	public static final RegistryObject<Block> OPAL_BLOCK = REGISTRY.register("opal_block", () -> new OpalBlockBlock());
	public static final RegistryObject<Block> IOLITE_BLOCK = REGISTRY.register("iolite_block", () -> new IoliteBlockBlock());
	public static final RegistryObject<Block> ZIRCON_BLOCK = REGISTRY.register("zircon_block", () -> new ZirconBlockBlock());
	public static final RegistryObject<Block> SPINEL_BLOCK = REGISTRY.register("spinel_block", () -> new SpinelBlockBlock());
	public static final RegistryObject<Block> BARREN_TOMB = REGISTRY.register("barren_tomb", () -> new BarrenTombBlock());
	public static final RegistryObject<Block> ORBOF_OBSCURITY = REGISTRY.register("orbof_obscurity", () -> new OrbofObscurityBlock());
	public static final RegistryObject<Block> AMETRINE_NETHER_ORE = REGISTRY.register("ametrine_nether_ore", () -> new AmetrineNetherOreBlock());
	public static final RegistryObject<Block> AMETRINE_BLOCK = REGISTRY.register("ametrine_block", () -> new AmetrineBlockBlock());
	public static final RegistryObject<Block> KUNZITE_NETHER_ORE = REGISTRY.register("kunzite_nether_ore", () -> new KunziteNetherOreBlock());
	public static final RegistryObject<Block> KUNZITE_BLOCK = REGISTRY.register("kunzite_block", () -> new KunziteBlockBlock());
	public static final RegistryObject<Block> PERIDOT_ENDSTONE_ORE = REGISTRY.register("peridot_endstone_ore", () -> new PeridotEndstoneOreBlock());
	public static final RegistryObject<Block> PERIDOT_BLOCK = REGISTRY.register("peridot_block", () -> new PeridotBlockBlock());
	public static final RegistryObject<Block> MANTLE_KILN = REGISTRY.register("mantle_kiln", () -> new MantleKilnBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
