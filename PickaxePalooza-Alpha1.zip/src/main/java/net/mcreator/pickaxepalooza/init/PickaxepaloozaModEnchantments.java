
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pickaxepalooza.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.pickaxepalooza.enchantment.SpineEnchantment;
import net.mcreator.pickaxepalooza.enchantment.PureHeartEnchantment;
import net.mcreator.pickaxepalooza.enchantment.AmplifyEnchantment;
import net.mcreator.pickaxepalooza.PickaxepaloozaMod;

public class PickaxepaloozaModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, PickaxepaloozaMod.MODID);
	public static final RegistryObject<Enchantment> PURE_HEART = REGISTRY.register("pure_heart", () -> new PureHeartEnchantment());
	public static final RegistryObject<Enchantment> AMPLIFY = REGISTRY.register("amplify", () -> new AmplifyEnchantment());
	public static final RegistryObject<Enchantment> SPINE = REGISTRY.register("spine", () -> new SpineEnchantment());
}
