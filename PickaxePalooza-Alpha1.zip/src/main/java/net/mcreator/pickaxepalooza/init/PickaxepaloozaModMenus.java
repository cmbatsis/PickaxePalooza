
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pickaxepalooza.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.pickaxepalooza.world.inventory.TomeoftimeGuiMenu;
import net.mcreator.pickaxepalooza.world.inventory.MantleKilnGuiMenu;
import net.mcreator.pickaxepalooza.world.inventory.HarbingerGuiMenu;
import net.mcreator.pickaxepalooza.world.inventory.GlimmerquiverguiMenu;
import net.mcreator.pickaxepalooza.PickaxepaloozaMod;

public class PickaxepaloozaModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, PickaxepaloozaMod.MODID);
	public static final RegistryObject<MenuType<HarbingerGuiMenu>> HARBINGER_GUI = REGISTRY.register("harbinger_gui", () -> IForgeMenuType.create(HarbingerGuiMenu::new));
	public static final RegistryObject<MenuType<GlimmerquiverguiMenu>> GLIMMERQUIVERGUI = REGISTRY.register("glimmerquivergui", () -> IForgeMenuType.create(GlimmerquiverguiMenu::new));
	public static final RegistryObject<MenuType<TomeoftimeGuiMenu>> TOMEOFTIME_GUI = REGISTRY.register("tomeoftime_gui", () -> IForgeMenuType.create(TomeoftimeGuiMenu::new));
	public static final RegistryObject<MenuType<MantleKilnGuiMenu>> MANTLE_KILN_GUI = REGISTRY.register("mantle_kiln_gui", () -> IForgeMenuType.create(MantleKilnGuiMenu::new));
}
