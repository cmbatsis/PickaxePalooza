package net.mcreator.pickaxepalooza.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.pickaxepalooza.init.PickaxepaloozaModEnchantments;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class SpineActivationProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(Entity entity, Entity sourceentity) {
		execute(null, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (new ItemStack(Items.CROSSBOW).getEnchantmentLevel(PickaxepaloozaModEnchantments.SPINE.get()) == 1 && (entity instanceof Mob || entity instanceof Player || entity instanceof Animal) && sourceentity instanceof Player) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0));
		}
		if (new ItemStack(Items.CROSSBOW).getEnchantmentLevel(PickaxepaloozaModEnchantments.SPINE.get()) == 2 && (entity instanceof Mob || entity instanceof Player || entity instanceof Animal) && sourceentity instanceof Player) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 120, 0));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0));
		}
		if (new ItemStack(Items.CROSSBOW).getEnchantmentLevel(PickaxepaloozaModEnchantments.SPINE.get()) == 3 && (entity instanceof Mob || entity instanceof Player || entity instanceof Animal) && sourceentity instanceof Player) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 180, 0));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 180, 0));
		}
		if (new ItemStack(Items.CROSSBOW).getEnchantmentLevel(PickaxepaloozaModEnchantments.SPINE.get()) == 4 && (entity instanceof Mob || entity instanceof Player || entity instanceof Animal) && sourceentity instanceof Player) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 240, 0));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 240, 0));
		}
		if (new ItemStack(Items.CROSSBOW).getEnchantmentLevel(PickaxepaloozaModEnchantments.SPINE.get()) == 5 && (entity instanceof Mob || entity instanceof Player || entity instanceof Animal) && sourceentity instanceof Player) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 300, 0));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 300, 0));
		}
	}
}
