
package net.mcreator.pickaxepalooza.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AmetrineItem extends Item {
	public AmetrineItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
