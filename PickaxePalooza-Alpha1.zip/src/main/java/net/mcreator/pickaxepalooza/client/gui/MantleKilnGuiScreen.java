package net.mcreator.pickaxepalooza.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.pickaxepalooza.world.inventory.MantleKilnGuiMenu;
import net.mcreator.pickaxepalooza.network.MantleKilnGuiButtonMessage;
import net.mcreator.pickaxepalooza.PickaxepaloozaMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class MantleKilnGuiScreen extends AbstractContainerScreen<MantleKilnGuiMenu> {
	private final static HashMap<String, Object> guistate = MantleKilnGuiMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_merge;

	public MantleKilnGuiScreen(MantleKilnGuiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = new ResourceLocation("pickaxepalooza:textures/screens/mantle_kiln_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		guiGraphics.blit(new ResourceLocation("pickaxepalooza:textures/screens/mantlekilnmagicwand.png"), this.leftPos + 13, this.topPos + 5, 0, 0, 32, 32, 32, 32);

		guiGraphics.blit(new ResourceLocation("pickaxepalooza:textures/screens/plussign.png"), this.leftPos + 45, this.topPos + 31, 0, 0, 32, 32, 32, 32);

		guiGraphics.blit(new ResourceLocation("pickaxepalooza:textures/screens/arrowgui.png"), this.leftPos + 100, this.topPos + 31, 0, 0, 32, 32, 32, 32);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.pickaxepalooza.mantle_kiln_gui.label_inventory"), 8, 69, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.pickaxepalooza.mantle_kiln_gui.label_combine_forge"), 73, 13, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		button_merge = Button.builder(Component.translatable("gui.pickaxepalooza.mantle_kiln_gui.button_merge"), e -> {
			if (true) {
				PickaxepaloozaMod.PACKET_HANDLER.sendToServer(new MantleKilnGuiButtonMessage(0, x, y, z));
				MantleKilnGuiButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 90, this.topPos + 59, 51, 20).build();
		guistate.put("button:button_merge", button_merge);
		this.addRenderableWidget(button_merge);
	}
}
